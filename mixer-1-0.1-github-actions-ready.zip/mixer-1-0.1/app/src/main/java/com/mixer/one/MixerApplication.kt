package com.mixer.one

import android.app.Application
import android.os.Build
import android.util.Log
import org.lsposed.hiddenapibypass.HiddenApiBypass

/**
 * Application class for Mixer.
 * Initializes HiddenApiBypass to allow reflection access to hidden Android APIs
 * required for per-app volume control via AudioPlaybackConfiguration.
 */
class MixerApplication : Application() {

    companion object {
        private const val TAG = "MixerApplication"
    }

    override fun onCreate() {
        super.onCreate()

        // Initialize HiddenApiBypass on Android P+ (API 28+)
        // This allows us to access hidden APIs like:
        // - AudioPlaybackConfiguration.getPlayerProxy()
        // - AudioPlaybackConfiguration.getClientUid()
        // - PlayerProxy.setVolume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // Exempt all hidden APIs (empty string matches all - from VolumeManager)
                HiddenApiBypass.addHiddenApiExemptions("")
                Log.d(TAG, "HiddenApiBypass initialized successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize HiddenApiBypass", e)
            }
        }
    }
}
